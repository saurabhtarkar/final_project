from . graph_widget import GraphWidget
